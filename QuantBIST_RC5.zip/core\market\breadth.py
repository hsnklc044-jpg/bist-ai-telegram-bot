"""
QuantBIST RC5
Market Breadth Intelligence Engine
"""

from __future__ import annotations


from core.infrastructure.exceptions import (
    MarketError,
)

from core.infrastructure.logger import (
    get_logger,
)

from core.market.indicators import (
    generate_indicator_snapshot,
)

from core.market.models import (
    BreadthStatus,
    MarketBreadth,
)



logger = get_logger(__name__)




# =====================================================
# CONFIG
# =====================================================


DEFAULT_MARKET_SYMBOL = "^XU100.IS"



TREND_WEIGHT = 0.35

RSI_WEIGHT = 0.20

MACD_WEIGHT = 0.20

EMA_WEIGHT = 0.25





# =====================================================
# SCORE HELPERS
# =====================================================


def _trend_score(
    snapshot,
) -> float:
    """
    Trend strength score.
    """


    value = snapshot.trend.value



    if value == "BULLISH":

        return 100



    if value == "NEUTRAL":

        return 55



    return 20





def _rsi_score(
    snapshot,
) -> float:
    """
    RSI market participation score.
    """


    rsi = snapshot.rsi



    if 45 <= rsi <= 65:

        return 100



    if 35 <= rsi <= 75:

        return 60



    if rsi < 30:

        return 70



    return 25





def _macd_score(
    snapshot,
) -> float:
    """
    MACD trend confirmation.
    """


    if snapshot.macd > snapshot.macd_signal:

        return 100



    return 30





def _ema_score(
    snapshot,
) -> float:
    """
    Long-term market direction.
    """


    if snapshot.price > snapshot.ema200:

        return 100



    return 30





def _normalize(
    score: float,
) -> float:
    """
    Normalize score.
    """


    return round(

        max(

            0,

            min(

                score,

                100,

            ),

        ),

        2,

    )





def _summary(
    status: BreadthStatus,
    score: float,
) -> str:
    """
    Create breadth summary.
    """


    return (

        f"{status.value} "

        f"({score:.0f}/100)"

    )





# =====================================================
# PUBLIC API
# =====================================================


def calculate_market_breadth(
    symbol: str = DEFAULT_MARKET_SYMBOL,
) -> MarketBreadth:
    """
    Calculate market breadth intelligence.

    Factors:

    Trend
    RSI
    MACD
    EMA200

    """



    logger.info(

        "Market breadth analysis started | %s",

        symbol,

    )



    try:



        snapshot = generate_indicator_snapshot(

            symbol,

        )



        trend = _trend_score(

            snapshot,

        )


        rsi = _rsi_score(

            snapshot,

        )


        macd = _macd_score(

            snapshot,

        )


        ema = _ema_score(

            snapshot,

        )




        score = (

            trend * TREND_WEIGHT

            +

            rsi * RSI_WEIGHT

            +

            macd * MACD_WEIGHT

            +

            ema * EMA_WEIGHT

        )



        score = _normalize(

            score,

        )





        if score >= 70:


            status = BreadthStatus.POSITIVE



        elif score >= 45:


            status = BreadthStatus.NEUTRAL



        else:


            status = BreadthStatus.NEGATIVE





        summary = _summary(

            status,

            score,

        )





        logger.info(

            "Breadth completed | %s | Score=%s",

            status.value,

            score,

        )





        return MarketBreadth(



            status=status,



            score=score,



            summary=summary,



        )





    except Exception as exc:



        logger.exception(

            "Market breadth failed."

        )



        raise MarketError(

            str(exc)

        ) from exc





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "calculate_market_breadth",

]