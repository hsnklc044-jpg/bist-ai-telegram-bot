"""
QuantBIST RC5
Investment Committee Engine
"""

from __future__ import annotations


from core.committee.models import (
    CommitteeMember,
    CommitteeResult,
    CommitteeVote,
    Vote,
)

from core.committee.scoring import (
    generate_scorecard,
)

from core.committee.voting import (
    conduct_vote,
)

from core.infrastructure.exceptions import (
    DecisionError,
)

from core.infrastructure.logger import (
    get_logger,
)

from core.market.models import (
    MarketStatus,
)

from core.portfolio.models import (
    PortfolioAnalysis,
)



logger = get_logger(__name__)




# =====================================================
# HELPERS
# =====================================================


def _score_to_vote(
    score: float,
) -> Vote:
    """
    Convert score into committee decision.
    """


    if score >= 90:

        return Vote.STRONG_BUY



    if score >= 75:

        return Vote.BUY



    if score >= 55:

        return Vote.HOLD



    if score >= 35:

        return Vote.REDUCE



    return Vote.SELL





def _confidence(
    score: float,
) -> int:
    """
    Convert score into confidence.
    """


    return max(

        50,

        min(

            99,

            round(score),

        ),

    )





def _summary(
    member: CommitteeMember,
    vote: Vote,
    score: float,
) -> str:
    """
    Create committee member summary.
    """


    return (

        f"{member.value}: "

        f"{vote.value} "

        f"({score:.1f})"

    )





def _reason(
    member: CommitteeMember,
    score: float,
) -> str:
    """
    Generate committee reasoning.
    """


    if score >= 75:

        return (

            f"{member.value} olumlu değerlendirme yaptı."

        )


    if score >= 50:

        return (

            f"{member.value} dengeli görüş bildirdi."

        )


    return (

        f"{member.value} risk nedeniyle temkinli yaklaştı."

    )





def _decision_factors(
    scorecard: dict,
) -> dict[str, float]:
    """
    Prepare decision factors.
    """


    return {

        "portfolio":
            float(
                scorecard.get(
                    "portfolio",
                    0,
                )
            ),


        "market":
            float(
                scorecard.get(
                    "market",
                    0,
                )
            ),


        "risk":
            float(
                scorecard.get(
                    "risk",
                    0,
                )
            ),


        "ai":
            float(
                scorecard.get(
                    "ai",
                    0,
                )
            ),

    }





# =====================================================
# PUBLIC API
# =====================================================


def run_committee(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> CommitteeResult:
    """
    Execute complete AI Investment Committee.
    """



    logger.info(

        "Investment Committee started."

    )



    try:



        scorecard = generate_scorecard(

            portfolio,

            market,

        )




        members = [

            (

                CommitteeMember.PORTFOLIO_MANAGER,

                scorecard["portfolio"],

            ),


            (

                CommitteeMember.MARKET_ANALYST,

                scorecard["market"],

            ),


            (

                CommitteeMember.RISK_MANAGER,

                scorecard["risk"],

            ),


            (

                CommitteeMember.AI_ANALYST,

                scorecard["ai"],

            ),

        ]





        votes: list[CommitteeVote] = []

        explanations: list[str] = []




        for member, score in members:



            vote = _score_to_vote(

                score,

            )



            explanations.append(

                _reason(

                    member,

                    score,

                )

            )



            votes.append(



                CommitteeVote(



                    member=member,



                    vote=vote,



                    confidence=_confidence(

                        score,

                    ),



                    score=round(

                        score,

                        2,

                    ),



                    summary=_summary(

                        member,

                        vote,

                        score,

                    ),



                    reasoning=[

                        _reason(

                            member,

                            score,

                        )

                    ],



                )



            )






        result = conduct_vote(

            votes,

        )




        result.explanation = explanations



        result.decision_factors = _decision_factors(

            scorecard,

        )





        logger.info(


            "Committee finished | Action=%s | Confidence=%d",


            result.action.value,


            result.confidence,


        )



        return result




    except Exception as exc:



        logger.exception(

            "Investment Committee failed."

        )



        raise DecisionError(

            str(exc)

        ) from exc





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "run_committee",

]