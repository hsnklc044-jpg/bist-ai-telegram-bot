"""
QuantBIST RC5
Decision Intelligence Builder

Builds final AI investment decision.
"""

from __future__ import annotations


from datetime import datetime
from uuid import uuid4


from core.ai.scoring import calculate_score

from core.committee.models import CommitteeResult

from core.decision.models import Decision

from core.market.models import MarketStatus

from core.portfolio.models import PortfolioAnalysis




# =====================================================
# HELPERS
# =====================================================


def _generate_decision_id() -> str:

    return (

        f"DEC-{datetime.now():%Y%m%d}-"

        f"{uuid4().hex[:8].upper()}"

    )





def _best_symbol(
    portfolio: PortfolioAnalysis,
) -> str:

    return portfolio.optimization.largest_position





def _worst_symbol(
    portfolio: PortfolioAnalysis,
) -> str:

    return portfolio.optimization.smallest_position





def _risk_score(
    portfolio: PortfolioAnalysis,
) -> float:


    mapping = {

        "LOW": 20.0,

        "MEDIUM": 50.0,

        "HIGH": 75.0,

        "CRITICAL": 95.0,

    }


    return mapping.get(

        str(

            portfolio.risk.level

        ).upper(),

        50.0,

    )





def _summary(
    committee: CommitteeResult,
) -> str:


    if committee.summary:

        return committee.summary



    return (

        f"{committee.action.value} "

        f"(Güven {committee.confidence}%)"

    )





# =====================================================
# AI EXPLANATION
# =====================================================


def _ai_explanation(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
    committee: CommitteeResult,
) -> list[str]:


    explanation = []


    explanation.append(

        f"Piyasa rejimi: "

        f"{market.regime.status.value}"

    )


    explanation.append(

        f"Portföy sağlığı: "

        f"{portfolio.health.score}/100"

    )


    explanation.append(

        f"Risk seviyesi: "

        f"{portfolio.risk.level}"

    )


    explanation.append(

        f"Komite kararı: "

        f"{committee.action.value}"

    )



    if portfolio.rebalance.needs_rebalance:

        explanation.append(

            "Portföy dengesi için yeniden dağılım öneriliyor."

        )



    if market.risk_off:

        explanation.append(

            "Piyasa riskten kaçış bölgesinde."

        )


    if market.risk_on:

        explanation.append(

            "Piyasa risk alma koşullarını destekliyor."

        )


    return explanation





# =====================================================
# SCORE BREAKDOWN
# =====================================================


def _score_breakdown(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
    committee: CommitteeResult,
) -> dict[str,float]:


    return {


        "portfolio_health":

            float(

                portfolio.health.score

            ),



        "committee_score":

            float(

                committee.score

            ),



        "market_score":

            float(

                market.market_score

            ),



        "risk_penalty":

            -float(

                _risk_score(portfolio)

            ),



    }





# =====================================================
# CONTEXT
# =====================================================


def _decision_context(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> dict[str,str]:


    return {


        "market_status":

            str(

                market.status

            ),



        "market_trend":

            market.trend.value,



        "market_regime":

            market.regime.status.value,



        "portfolio_grade":

            str(

                portfolio.health.grade

            ),



        "risk_level":

            str(

                portfolio.risk.level

            ),

    }





# =====================================================
# WARNINGS
# =====================================================


def _warnings(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> list[str]:


    warnings = []



    if portfolio.rebalance.needs_rebalance:

        warnings.append(

            "Portföy yeniden dengelenmeli."

        )



    if portfolio.optimization.concentration_risk:

        warnings.append(

            "Yoğunlaşma riski mevcut."

        )



    if market.risk_off:

        warnings.append(

            "Piyasa Risk-Off bölgesinde."

        )



    if market.volatility.value == "HIGH":

        warnings.append(

            "Yüksek volatilite mevcut."

        )



    return warnings





# =====================================================
# SUGGESTIONS
# =====================================================


def _suggestions(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> list[str]:


    suggestions = []



    if market.risk_on:

        suggestions.append(

            "Seçici hisse ağırlığı artırılabilir."

        )



    if portfolio.rebalance.needs_rebalance:

        suggestions.append(

            "Hedef portföy ağırlıkları kontrol edilmeli."

        )



    if portfolio.health.score >= 80:

        suggestions.append(

            "Mevcut strateji korunabilir."

        )



    if not suggestions:

        suggestions.append(

            "Piyasa gelişmeleri takip edilmeli."

        )


    return suggestions





# =====================================================
# PRIORITY
# =====================================================


def _decision_priority(
    committee: CommitteeResult,
    portfolio: PortfolioAnalysis,
) -> str:


    if str(portfolio.risk.level).upper() == "CRITICAL":

        return "CRITICAL"



    if committee.confidence >= 80:

        return "HIGH"



    if committee.confidence >= 60:

        return "MEDIUM"



    return "LOW"





# =====================================================
# PUBLIC API
# =====================================================


def build_decision(
    committee: CommitteeResult,
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> Decision:


    ai_score = calculate_score(

        portfolio,

        market,

    )


    risk_score = _risk_score(

        portfolio,

    )



    return Decision(



        decision_id=_generate_decision_id(),


        timestamp=datetime.now(),


        engine_version="RC5",




        action=committee.action.value,


        score=round(ai_score),


        confidence=committee.confidence,


        priority=_decision_priority(

            committee,

            portfolio,

        ),


        summary=_summary(

            committee,

        ),




        ai_score=round(ai_score),




        ai_explanation=_ai_explanation(

            portfolio,

            market,

            committee,

        ),




        score_breakdown=_score_breakdown(

            portfolio,

            market,

            committee,

        ),




        decision_context=_decision_context(

            portfolio,

            market,

        ),




        committee_action=committee.action.value,


        committee_score=committee.score,


        committee_consensus=committee.consensus,




        portfolio_health=portfolio.health.score,


        portfolio_grade=portfolio.health.grade,


        best_symbol=_best_symbol(portfolio),


        worst_symbol=_worst_symbol(portfolio),


        rebalance_required=portfolio.rebalance.needs_rebalance,




        risk_level=str(portfolio.risk.level),


        risk_score=risk_score,




        market_status=market.status,


        market_trend=market.trend.value,


        market_regime=market.regime.status.value,




        reasons=[

            vote.summary

            for vote in committee.votes

        ],



        suggestions=_suggestions(

            portfolio,

            market,

        ),



        warnings=_warnings(

            portfolio,

            market,

        ),


    )





__all__ = [

    "build_decision",

]