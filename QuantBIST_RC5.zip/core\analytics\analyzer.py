"""
QuantBIST RC5
Market Analyzer
"""

from __future__ import annotations


from core.analytics.scoring import calculate_score
from core.infrastructure.logger import get_logger
from core.market.data import load_price_history
from core.market.indicators import generate_indicator_snapshot


logger = get_logger(__name__)



# =====================================================
# HELPERS
# =====================================================


def _calculate_confidence(
    score: int,
) -> int:
    """
    Convert AI score into confidence.
    """

    confidence = score + 10

    if confidence > 99:
        confidence = 99

    if confidence < 0:
        confidence = 0

    return confidence



def _generate_reason(
    snapshot,
    signal: str,
) -> list[str]:
    """
    Generate analysis explanation.
    """

    reasons = []


    if snapshot.trend:

        reasons.append(
            f"Trend: {snapshot.trend.value}"
        )


    if snapshot.rsi:

        if snapshot.rsi < 30:

            reasons.append(
                "RSI aşırı satış bölgesinde."
            )

        elif snapshot.rsi > 70:

            reasons.append(
                "RSI aşırı alım bölgesinde."
            )

        else:

            reasons.append(
                "RSI dengeli seviyede."
            )


    if snapshot.momentum:

        reasons.append(
            "Momentum pozitif."
        )


    reasons.append(
        f"Sinyal: {signal}"
    )


    return reasons




def _risk_level(
    volatility: float,
) -> str:
    """
    Determine risk level.
    """

    if volatility >= 0.05:

        return "HIGH"


    if volatility >= 0.03:

        return "MEDIUM"


    return "LOW"




# =====================================================
# PUBLIC API
# =====================================================


def analyze_stock(
    symbol: str,
) -> dict | None:
    """
    Analyze stock and return RC5 signal data.
    """

    try:


        df = load_price_history(
            symbol,
        )


        if df.empty:

            return None



        snapshot = generate_indicator_snapshot(
            symbol,
        )



        volatility = round(

            snapshot.atr / snapshot.price,

            4,

        )



        score_data = calculate_score(

            ma20=snapshot.ema20,

            ma50=snapshot.ema50,

            rsi=snapshot.rsi,

            macd=snapshot.macd,

            volume_ratio=1.0,

            volatility=volatility,

        )



        score = score_data.get(
            "score",
            0,
        )



        signal = score_data.get(
            "signal",
            "WATCH",
        )



        atr = round(
            snapshot.atr,
            2,
        )


        entry_price = round(
            snapshot.price,
            2,
        )



        stop_loss = round(

            entry_price - atr * 2,

            2,

        )



        target_1 = round(

            entry_price + atr * 2,

            2,

        )



        target_2 = round(

            entry_price + atr * 4,

            2,

        )



        return {


            # -----------------------------------------
            # Identity
            # -----------------------------------------

            "symbol": symbol,


            # -----------------------------------------
            # Price
            # -----------------------------------------

            "price": entry_price,



            # -----------------------------------------
            # AI Score
            # -----------------------------------------

            **score_data,


            "confidence": _calculate_confidence(
                score,
            ),



            # -----------------------------------------
            # Indicators
            # -----------------------------------------

            "rsi": snapshot.rsi,

            "macd": snapshot.macd,

            "volume_ratio": 1.0,

            "volatility": volatility,


            "trend":
                snapshot.trend.value,


            "momentum":
                snapshot.momentum,



            # -----------------------------------------
            # Risk
            # -----------------------------------------

            "risk_level":
                _risk_level(
                    volatility,
                ),



            # -----------------------------------------
            # AI Explanation
            # -----------------------------------------

            "reasons":
                _generate_reason(

                    snapshot,

                    signal,

                ),



            # -----------------------------------------
            # Trade Levels
            # -----------------------------------------

            "atr": atr,


            "entry_price": entry_price,


            "stop_loss": stop_loss,


            "target_1": target_1,


            "target_2": target_2,



            # -----------------------------------------
            # Moving Average
            # -----------------------------------------

            "ma20":
                snapshot.ema20,


            "ma50":
                snapshot.ema50,


        }



    except Exception as exc:


        logger.exception(

            "Stock analysis failed | %s | %s",

            symbol,

            exc,

        )


        return None





__all__ = [

    "analyze_stock",

]