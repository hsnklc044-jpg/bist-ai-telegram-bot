"""
QuantBIST RC5
Signal Analytics
"""

from __future__ import annotations

from core.analytics.analyzer import analyze_stock
from core.infrastructure.logger import get_logger


logger = get_logger(__name__)



# =====================================================
# DEFAULT SYMBOLS
# =====================================================


DEFAULT_SYMBOLS = [

    "SASA.IS",

    "SISE.IS",

    "THYAO.IS",

    "TUPRS.IS",

    "ASELS.IS",

    "KCHOL.IS",

    "YKBNK.IS",

    "BIMAS.IS",

    "HEKTS.IS",

    "PETKM.IS",

    "TCELL.IS",

    "GARAN.IS",

    "AKBNK.IS",

    "EREGL.IS",

]




# =====================================================
# SIGNAL ENGINE
# =====================================================


def get_top_signals(
    symbols: list[str] | None = None,
) -> list[dict]:
    """
    Return highest scoring trading opportunities.

    RC5 Signal Pipeline

    Symbol
        ↓
    Stock Analyzer
        ↓
    Signal Filter
        ↓
    Score Ranking
        ↓
    Dashboard

    """



    if symbols is None:

        symbols = DEFAULT_SYMBOLS



    opportunities: list[dict] = []



    for symbol in symbols:


        try:


            result = analyze_stock(
                symbol,
            )



            if not result:

                continue



            signal = result.get(
                "signal",
            )



            score = result.get(
                "score",
                0,
            )



            # -----------------------------------------
            # Signal Filter
            # -----------------------------------------


            if signal not in (

                "WATCH",

                "BUY",

                "STRONG BUY",

            ):

                continue



            if score < 50:

                continue




            # -----------------------------------------
            # RC5 Metadata
            # -----------------------------------------


            result.setdefault(
                "symbol",
                symbol,
            )


            result.setdefault(
                "confidence",
                score,
            )


            result.setdefault(
                "rank",
                0,
            )


            opportunities.append(
                result,
            )



        except Exception as exc:


            logger.warning(

                "Signal analysis failed | %s | %s",

                symbol,

                exc,

            )


            continue




    # ---------------------------------------------
    # Ranking
    # ---------------------------------------------


    opportunities.sort(

        key=lambda item:

        item.get(
            "score",
            0,
        ),

        reverse=True,

    )



    # ---------------------------------------------
    # Rank Assignment
    # ---------------------------------------------


    for index, item in enumerate(

        opportunities,

        start=1,

    ):

        item["rank"] = index




    return opportunities[:10]





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "get_top_signals",

]