"""
QuantBIST RC5
Market Regime Intelligence Engine
"""

from __future__ import annotations


from core.infrastructure.exceptions import (
    MarketError,
)

from core.infrastructure.logger import (
    get_logger,
)

from core.market.breadth import (
    calculate_market_breadth,
)

from core.market.indicators import (
    generate_indicator_snapshot,
)

from core.market.models import (
    MarketRegime,
    MarketRegimeType,
    MarketTrend,
)

from core.market.sentiment import (
    calculate_market_sentiment,
)



logger = get_logger(__name__)




# =====================================================
# CONFIG
# =====================================================


DEFAULT_MARKET_SYMBOL = "^XU100.IS"



TREND_WEIGHT = 0.40

BREADTH_WEIGHT = 0.30

SENTIMENT_WEIGHT = 0.30





# =====================================================
# SCORE HELPERS
# =====================================================


def _trend_score(
    trend: MarketTrend,
) -> float:
    """
    Calculate trend contribution.
    """


    if trend is MarketTrend.BULLISH:

        return 100



    if trend is MarketTrend.NEUTRAL:

        return 50



    return 0





def _normalize(
    value: float,
) -> float:
    """
    Keep score between 0-100.
    """


    return round(

        max(

            0,

            min(

                value,

                100,

            ),

        ),

        2,

    )





def _summary(
    status: MarketRegimeType,
    score: float,
) -> str:
    """
    Create market regime summary.
    """


    return (

        f"{status.value} "

        f"({score:.0f}/100)"

    )





# =====================================================
# PUBLIC API
# =====================================================


def determine_market_regime(
    symbol: str = DEFAULT_MARKET_SYMBOL,
) -> MarketRegime:
    """
    Determine current market regime.

    RC5 Market Intelligence Flow:

    Trend
       +
    Breadth
       +
    Sentiment
       ↓
    Market Regime

    """



    logger.info(

        "Market regime analysis started | %s",

        symbol,

    )



    try:



        snapshot = generate_indicator_snapshot(

            symbol,

        )



        breadth = calculate_market_breadth(

            symbol,

        )



        sentiment = calculate_market_sentiment(

            symbol,

        )




        trend_value = _trend_score(

            snapshot.trend,

        )



        breadth_value = breadth.score



        sentiment_value = sentiment.score





        score = (

            trend_value * TREND_WEIGHT

            +

            breadth_value * BREADTH_WEIGHT

            +

            sentiment_value * SENTIMENT_WEIGHT

        )



        score = _normalize(

            score,

        )





        if score >= 70:


            status = MarketRegimeType.RISK_ON



        elif score >= 45:


            status = MarketRegimeType.NEUTRAL



        else:


            status = MarketRegimeType.RISK_OFF





        summary = _summary(

            status,

            score,

        )





        logger.info(

            "Market regime completed | %s | Score=%s",

            status.value,

            score,

        )





        return MarketRegime(



            status=status,



            score=score,



            summary=summary,



        )





    except Exception as exc:



        logger.exception(

            "Market regime calculation failed."

        )



        raise MarketError(

            str(exc)

        ) from exc





# =====================================================
# HELPERS
# =====================================================


def is_risk_on(
    regime: MarketRegime,
) -> bool:
    """
    Risk-On market?
    """


    return regime.status is MarketRegimeType.RISK_ON





def is_risk_off(
    regime: MarketRegime,
) -> bool:
    """
    Risk-Off market?
    """


    return regime.status is MarketRegimeType.RISK_OFF





def is_neutral(
    regime: MarketRegime,
) -> bool:
    """
    Neutral market?
    """


    return regime.status is MarketRegimeType.NEUTRAL





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "determine_market_regime",

    "is_risk_on",

    "is_risk_off",

    "is_neutral",

]