"""
QuantBIST RC5
Decision Intelligence Models
"""

from __future__ import annotations


from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum





# =====================================================
# ENUMS
# =====================================================


class DecisionAction(Enum):

    STRONG_BUY = "STRONG BUY"

    BUY = "BUY"

    ACCUMULATE = "ACCUMULATE"

    WATCH = "WATCH"

    HOLD = "HOLD"

    REDUCE = "REDUCE"

    SELL = "SELL"

    STRONG_SELL = "STRONG SELL"





class RiskLevel(Enum):

    LOW = "LOW"

    MEDIUM = "MEDIUM"

    HIGH = "HIGH"

    CRITICAL = "CRITICAL"





class PriorityLevel(Enum):

    LOW = "LOW"

    NORMAL = "NORMAL"

    HIGH = "HIGH"

    CRITICAL = "CRITICAL"






# =====================================================
# DECISION MODEL
# =====================================================


@dataclass(slots=True)
class Decision:
    """
    QuantBIST Final AI Decision Model.

    Single source of truth:

    - Dashboard
    - API
    - Reports
    - Telegram
    - AI explanations

    """



    # =================================================
    # Identity
    # =================================================


    decision_id: str = ""


    timestamp: datetime = field(

        default_factory=datetime.now,

    )


    engine_version: str = "RC5"






    # =================================================
    # Final Decision
    # =================================================


    action: str = "HOLD"


    score: int = 0


    confidence: int = 0


    priority: str = "NORMAL"


    summary: str = ""






    # =================================================
    # AI Intelligence Layer
    # =================================================


    ai_score: int = 0



    ai_explanation: list[str] = field(

        default_factory=list,

    )



    score_breakdown: dict[str,float] = field(

        default_factory=dict,

    )



    decision_context: dict[str,str] = field(

        default_factory=dict,

    )






    # =================================================
    # Committee
    # =================================================


    committee_action: str = ""


    committee_score: float = 0.0


    committee_consensus: float = 0.0






    # =================================================
    # Portfolio Intelligence
    # =================================================


    portfolio_health: float = 0.0


    portfolio_grade: str = ""


    best_symbol: str = ""


    worst_symbol: str = ""


    rebalance_required: bool = False






    # =================================================
    # Risk Intelligence
    # =================================================


    risk_level: str = RiskLevel.LOW.value


    risk_score: float = 0.0






    # =================================================
    # Market Intelligence
    # =================================================


    market_status: str = ""


    market_trend: str = ""


    market_regime: str = ""






    # =================================================
    # Messages
    # =================================================


    reasons: list[str] = field(

        default_factory=list,

    )



    suggestions: list[str] = field(

        default_factory=list,

    )



    warnings: list[str] = field(

        default_factory=list,

    )







    # =================================================
    # PROPERTIES
    # =================================================


    @property
    def buy_signal(
        self,
    ) -> bool:
        """
        Buy recommendation?
        """


        return self.action in (

            DecisionAction.STRONG_BUY.value,

            DecisionAction.BUY.value,

            DecisionAction.ACCUMULATE.value,

        )





    @property
    def sell_signal(
        self,
    ) -> bool:
        """
        Sell recommendation?
        """


        return self.action in (

            DecisionAction.REDUCE.value,

            DecisionAction.SELL.value,

            DecisionAction.STRONG_SELL.value,

        )





    @property
    def hold_signal(
        self,
    ) -> bool:
        """
        Hold recommendation?
        """


        return self.action in (

            DecisionAction.HOLD.value,

            DecisionAction.WATCH.value,

        )





    @property
    def rebalance_signal(
        self,
    ) -> bool:


        return self.rebalance_required





    @property
    def healthy(
        self,
    ) -> bool:


        return self.portfolio_health >= 80





    @property
    def high_confidence(
        self,
    ) -> bool:


        return self.confidence >= 80





    @property
    def critical(
        self,
    ) -> bool:


        return (

            self.priority.upper()

            ==

            PriorityLevel.CRITICAL.value

        )





    @property
    def risk_is_high(
        self,
    ) -> bool:


        return self.risk_level.upper() in (

            RiskLevel.HIGH.value,

            RiskLevel.CRITICAL.value,

        )





    @property
    def investable(
        self,
    ) -> bool:
        """
        AI allows exposure?
        """


        return (

            self.buy_signal

            and

            self.confidence >= 60

        )






# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "Decision",

    "DecisionAction",

    "RiskLevel",

    "PriorityLevel",

]