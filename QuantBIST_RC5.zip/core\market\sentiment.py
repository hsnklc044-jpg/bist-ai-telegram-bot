"""
QuantBIST RC5
Market Sentiment Intelligence Engine
"""

from __future__ import annotations


from core.infrastructure.exceptions import (
    MarketError,
)

from core.infrastructure.logger import (
    get_logger,
)

from core.market.indicators import (
    generate_indicator_snapshot,
)

from core.market.models import (
    MarketSentiment,
    SentimentStatus,
)



logger = get_logger(__name__)




# =====================================================
# CONFIG
# =====================================================


DEFAULT_MARKET_SYMBOL = "^XU100.IS"



RSI_WEIGHT = 0.35

MACD_WEIGHT = 0.30

MOMENTUM_WEIGHT = 0.35





# =====================================================
# SCORE HELPERS
# =====================================================


def _rsi_score(
    snapshot,
) -> float:
    """
    RSI sentiment score.
    """


    if snapshot.rsi <= 30:

        return 90



    if snapshot.rsi < 40:

        return 70



    if snapshot.rsi > 80:

        return 15



    if snapshot.rsi > 70:

        return 30



    return 50





def _macd_score(
    snapshot,
) -> float:
    """
    MACD sentiment score.
    """


    if snapshot.macd > snapshot.macd_signal:

        return 75



    return 35





def _momentum_score(
    snapshot,
) -> float:
    """
    Momentum sentiment score.
    """


    mapping = {

        "POSITIVE": 80,

        "NEUTRAL": 50,

        "NEGATIVE": 20,

        "OVERBOUGHT": 35,

        "OVERSOLD": 75,

    }



    return mapping.get(

        snapshot.momentum,

        50,

    )





def _normalize(
    score: float,
) -> float:
    """
    Keep score between 0-100.
    """


    return round(

        max(

            0,

            min(

                score,

                100,

            ),

        ),

        2,

    )





def _summary(
    status: SentimentStatus,
    score: float,
) -> str:
    """
    Create sentiment summary.
    """


    return (

        f"{status.value} "

        f"({score:.0f}/100)"

    )





# =====================================================
# PUBLIC API
# =====================================================


def calculate_market_sentiment(
    symbol: str = DEFAULT_MARKET_SYMBOL,
) -> MarketSentiment:
    """
    Calculate market sentiment.

    Factors:

    RSI
    MACD
    Momentum

    """



    logger.info(

        "Market sentiment analysis started | %s",

        symbol,

    )



    try:



        snapshot = generate_indicator_snapshot(

            symbol,

        )



        rsi = _rsi_score(

            snapshot,

        )


        macd = _macd_score(

            snapshot,

        )


        momentum = _momentum_score(

            snapshot,

        )



        score = (

            rsi * RSI_WEIGHT

            +

            macd * MACD_WEIGHT

            +

            momentum * MOMENTUM_WEIGHT

        )



        score = _normalize(

            score,

        )





        if score >= 70:


            status = SentimentStatus.GREED



        elif score >= 45:


            status = SentimentStatus.NEUTRAL



        else:


            status = SentimentStatus.FEAR





        summary = _summary(

            status,

            score,

        )





        logger.info(

            "Sentiment completed | %s | Score=%s",

            status.value,

            score,

        )





        return MarketSentiment(



            status=status,



            score=score,



            summary=summary,



        )





    except Exception as exc:



        logger.exception(

            "Market sentiment failed."

        )



        raise MarketError(

            str(exc)

        ) from exc





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "calculate_market_sentiment",

]