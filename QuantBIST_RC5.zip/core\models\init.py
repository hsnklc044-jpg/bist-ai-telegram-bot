"""
QuantBIST Framework
Shared Models
"""