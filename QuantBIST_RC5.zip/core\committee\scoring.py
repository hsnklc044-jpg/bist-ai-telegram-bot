"""
QuantBIST RC5
Investment Committee Scoring Engine
"""

from __future__ import annotations


from core.infrastructure.logger import get_logger

from core.market.models import MarketStatus

from core.portfolio.models import PortfolioAnalysis



logger = get_logger(__name__)




# =====================================================
# CONSTANTS
# =====================================================


MAX_SCORE = 100

MIN_SCORE = 0



REBALANCE_PENALTY = 10

CONCENTRATION_PENALTY = 10

RISK_WEIGHT = 0.20




# =====================================================
# HELPERS
# =====================================================


def _normalize_score(
    score: float,
) -> float:
    """
    Keep score between 0-100.
    """


    return round(

        max(

            MIN_SCORE,

            min(

                score,

                MAX_SCORE,

            ),

        ),

        2,

    )





# =====================================================
# PORTFOLIO MANAGER
# =====================================================


def portfolio_score(
    portfolio: PortfolioAnalysis,
) -> float:
    """
    Portfolio Manager evaluation.

    Evaluates:

    - Portfolio health
    - Rebalance status
    - Risk impact

    """


    score = portfolio.health.score



    if portfolio.rebalance.needs_rebalance:

        score -= REBALANCE_PENALTY



    score -= (

        portfolio.risk.score

        *

        RISK_WEIGHT

    )



    return _normalize_score(

        score,

    )





# =====================================================
# MARKET ANALYST
# =====================================================


def market_score(
    market: MarketStatus,
) -> float:
    """
    Market Analyst evaluation.
    """


    return _normalize_score(

        market.market_score,

    )





# =====================================================
# RISK MANAGER
# =====================================================


def risk_score(
    portfolio: PortfolioAnalysis,
) -> float:
    """
    Risk Manager evaluation.

    Higher score means healthier risk profile.

    """


    score = MAX_SCORE



    score -= portfolio.risk.score



    if portfolio.optimization.concentration_risk:

        score -= CONCENTRATION_PENALTY



    if portfolio.rebalance.needs_rebalance:

        score -= REBALANCE_PENALTY



    return _normalize_score(

        score,

    )





# =====================================================
# AI ANALYST
# =====================================================


def ai_score(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> float:
    """
    AI Analyst evaluation.

    Combines:

    Portfolio
    Market
    Risk

    """


    portfolio_value = portfolio_score(

        portfolio,

    )


    market_value = market_score(

        market,

    )


    risk_value = risk_score(

        portfolio,

    )



    final_score = (

        portfolio_value * 0.40

        +

        market_value * 0.35

        +

        risk_value * 0.25

    )



    return _normalize_score(

        final_score,

    )





# =====================================================
# COMMITTEE SCORECARD
# =====================================================


def generate_scorecard(
    portfolio: PortfolioAnalysis,
    market: MarketStatus,
) -> dict[str, float]:
    """
    Generate complete committee scorecard.
    """


    logger.info(

        "Generating RC5 committee scorecard."

    )



    scorecard = {


        "portfolio":

            portfolio_score(

                portfolio,

            ),



        "market":

            market_score(

                market,

            ),



        "risk":

            risk_score(

                portfolio,

            ),



        "ai":

            ai_score(

                portfolio,

                market,

            ),


    }



    logger.info(

        "Committee scorecard ready | %s",

        scorecard,

    )



    return scorecard





# =====================================================
# EXPORTS
# =====================================================


__all__ = [

    "portfolio_score",

    "market_score",

    "risk_score",

    "ai_score",

    "generate_scorecard",

]